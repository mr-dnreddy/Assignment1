package com.dn.week1.a1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jakarta.servlet.http.HttpServlet;

@WebServlet("/AddTwoNumbers")
public class AddTwoNumbers extends HttpServlet {
	
	protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws IOException,ServletException
	{
		resp.setContentType("text/html");
		
		PrintWriter out = resp.getWriter();
		int n1=Integer.parseInt(req.getParameter("number1"));
		int n2=Integer.parseInt(req.getParameter("number2"));
		
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Addition</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("Sum is " + (n1+n2));
		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
