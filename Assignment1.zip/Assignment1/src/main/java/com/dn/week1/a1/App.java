package com.dn.week1.a1;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        EmployeeDAO employeeDAO = new EmployeeDAO();

        // Create a new employee
       employeeDAO.readEmployees();
       employeeDAO.createEmployee(2,"DN", "Reddy", 1);

        // Read all employees
        employeeDAO.readEmployees();

        // Update an employee
       employeeDAO.updateEmployee(2, "John", "Dheer", 1);
       
       employeeDAO.readEmployees();

        // Delete an employee
        employeeDAO.deleteEmployee(12);
        employeeDAO.readEmployees();
    }
}