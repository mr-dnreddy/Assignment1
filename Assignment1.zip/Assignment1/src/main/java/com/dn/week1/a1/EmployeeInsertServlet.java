package com.dn.week1.a1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/EmployeeInsertServlet")
public class EmployeeInsertServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp", "root", "Jambalakadijm@43");

            // Get employee details from request
            int eid = Integer.parseInt(request.getParameter("eid"));
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            int dept = Integer.parseInt(request.getParameter("dept"));

            // SQL query to insert employee
            String sql = "INSERT INTO Employees (,EmployeeID, FirstName, LastName, DepartmentID) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, eid);
            stmt.setString(2, fname);
            stmt.setString(3, lname);
            stmt.setInt(4, dept);

            // Execute update
            stmt.executeUpdate();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
