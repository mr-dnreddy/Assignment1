package com.dn.week1.a1;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/es")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp", "root", "Jambalakadijm@43");

            // Get employee ID from request
            String empId = request.getParameter("id");

            // SQL query to retrieve employee by ID
            String sql = "SELECT EmployeeID, FirstName, LastName, DepartmentID FROM Employees WHERE EmployeeID = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, empId);
            rs = stmt.executeQuery();

            // Display employee information
            out.println("<html><body>");
            out.println("<h2>Employee Details:</h2>");

            if (rs.next()) {
                int id = rs.getInt("EmployeeID");
                String fname = rs.getString("FirstName");
                String lname = rs.getString("LastName");
                int department = rs.getInt("DepartmentID");

                out.println("ID: " + id + ", First Name: " + fname + ", Last Name: " + lname + ", Department: " + department);
            } else {
                out.println("No employee found with ID: " + empId);
            }

            out.println("</body></html>");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
