package com.dn.week1.a1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/add")
public class AddServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Retrieve the values of num1 and num2 from the form
            String num1Str = request.getParameter("num1");
            String num2Str = request.getParameter("num2");

            // Parse the input strings as integers
            int num1 = Integer.parseInt(num1Str);
            int num2 = Integer.parseInt(num2Str);

            // Calculate the sum
            int sum = num1 + num2;

            // Set the content type for the response
            response.setContentType("text/html");

            // Write the result back to the client
            response.getWriter().println("<html><body>");
            response.getWriter().println("<h1>Result:</h1>");
            response.getWriter().println("<p>" + num1 + " + " + num2 + " = " + sum + "</p>");
            response.getWriter().println("</body></html>");
        } catch (NumberFormatException e) {
            // Handle invalid input (non-numeric values)
            response.getWriter().println("<html><body>");
            response.getWriter().println("<h1>Error:</h1>");
            response.getWriter().println("<p>Please enter valid numeric values.</p>");
            response.getWriter().println("</body></html>");
        }
    }
}

