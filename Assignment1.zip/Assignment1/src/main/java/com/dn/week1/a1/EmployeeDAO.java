package com.dn.week1.a1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class EmployeeDAO {
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/emp", "root", "Jambalakadijm@43");
    }

    public void createEmployee(int EmployeeID,String FirstName, String LastName, int departmentID) {
        String sql = "INSERT INTO Employees(EmployeeID, FirstName, LastName, DepartmentID) VALUES(?, ?, ?, ?)";

        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, EmployeeID);
			pstmt.setString(2, FirstName);
            pstmt.setString(3, LastName);
            pstmt.setInt(4, departmentID);
            
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public List<EmployeeDAO> readEmployees() {
        String sql = "SELECT * FROM Employees";

        try (Connection conn = this.connect();
             Statement stmt  = conn.createStatement();
             ResultSet rs    = stmt.executeQuery(sql)){
            
            while (rs.next()) {
                System.out.println(rs.getInt("EmployeeID") +  "\t" + 
                                   rs.getString("FirstName") + "\t" +
                                   rs.getString("LastName") + "\t" +
                                   rs.getInt("DepartmentID") + "\t" 
                                   );
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		return null;
    }

    public void updateEmployee(int employeeID, String firstName, String lastName, int departmentID) {
        String sql = "UPDATE Employees SET FirstName = ? , "
                   + "LastName = ? , "
                   + "DepartmentID = ? , "
                   + "WHERE EmployeeID = ?";

        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
        	 pstmt.setInt(5, employeeID);
            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setInt(3, departmentID);
                      
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void deleteEmployee(int employeeID) {
        String sql = "DELETE FROM Employees WHERE EmployeeID = ?";

        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, employeeID);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

