package com.dn.week1.a1;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@AllArgsConstructor
@Setter
public class Employee {
	private int EmployeeID;
	private String FirstName;
	private String LastName;
	private int DepartmentID;

}
